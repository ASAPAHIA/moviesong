package com.cg.movies.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movies.beans.Movie;
import com.cg.movies.beans.Song;
import com.cg.movies.daoServices.MoviesDao;
import com.cg.movies.daoServices.SongsDao;
import com.cg.movies.exceptions.MovieNotFoundException;
import com.cg.movies.exceptions.MovieIdNotFoundException;


@Component("moviesServices")
public class MoviesServicesImpl implements MoviesServices {
	@Autowired
    public MoviesDao moviesDao;
	@Autowired
    public SongsDao songsDao;

	@Override
	public Movie acceptMoviesDetails(Movie movie) {
		movie=moviesDao.save(movie);
		return movie;
	}

	@Override
	public Movie getMoviesDetails(int movieId) throws MovieNotFoundException {
		Movie movie=moviesDao.findById(movieId).orElseThrow(()->new MovieNotFoundException("Details not found for="+movieId));
		if(movie==null)
			throw new MovieNotFoundException("movie not found "+movieId);
		return movie;
	}

	@Override
	public boolean removeMovie(int movieId)throws MovieIdNotFoundException  {
	moviesDao.delete(getMoviesDetails(movieId));
		return true;
	}

	@Override
	public Movie addSongToMovie(int movieId, Song song) {
		Movie movie=moviesDao.findById(movieId).orElseThrow(()->new MovieNotFoundException("Details not found for="+movieId));
		if(movie==null)
			throw new MovieNotFoundException("movie not found "+movieId);
		song=songsDao.save(song);
		movie.song.put(song.getSongId(), song);
		return movie;
	}

	



}
