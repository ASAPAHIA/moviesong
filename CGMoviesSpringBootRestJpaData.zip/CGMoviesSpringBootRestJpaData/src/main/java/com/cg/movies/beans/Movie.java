package com.cg.movies.beans;

import java.util.Map;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@Entity
public class Movie {
	@Id
	@SequenceGenerator(name="movieId",initialValue=1001,allocationSize=9999,sequenceName="movieId")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="movieId")
	private int movieId;
private String movieName;
private String movieGenre;
@OneToMany(mappedBy="movie")
public Map<Integer,Song >song;
public Movie() {
	super();
}
public Movie(int movieId, String movieName, String movieGenre, Map<Integer, Song> song) {
	super();
	this.movieId = movieId;
	this.movieName = movieName;
	this.movieGenre = movieGenre;
	this.song = song;
}
public int getMovieId() {
	return movieId;
}
public void setMovieId(int movieId) {
	this.movieId = movieId;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getMovieGenre() {
	return movieGenre;
}
public void setMovieGenre(String movieGenre) {
	this.movieGenre = movieGenre;
}
public Map<Integer, Song> getSong() {
	return song;
}
public void setSong(Map<Integer, Song> song) {
	this.song = song;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((movieGenre == null) ? 0 : movieGenre.hashCode());
	result = prime * result + movieId;
	result = prime * result + ((movieName == null) ? 0 : movieName.hashCode());
	result = prime * result + ((song == null) ? 0 : song.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Movie other = (Movie) obj;
	if (movieGenre == null) {
		if (other.movieGenre != null)
			return false;
	} else if (!movieGenre.equals(other.movieGenre))
		return false;
	if (movieId != other.movieId)
		return false;
	if (movieName == null) {
		if (other.movieName != null)
			return false;
	} else if (!movieName.equals(other.movieName))
		return false;
	if (song == null) {
		if (other.song != null)
			return false;
	} else if (!song.equals(other.song))
		return false;
	return true;
}
@Override
public String toString() {
	return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", movieGenre=" + movieGenre + ", song=" + song
			+ "]";
}

}