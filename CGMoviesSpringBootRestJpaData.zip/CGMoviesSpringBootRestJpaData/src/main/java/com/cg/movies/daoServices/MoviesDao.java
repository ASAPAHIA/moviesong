package com.cg.movies.daoServices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.movies.beans.Movie;

public interface MoviesDao extends JpaRepository<Movie, Integer>{

}
