package com.cg.movies.services;

import com.cg.movies.beans.Movie;
import com.cg.movies.beans.Song;
import com.cg.movies.exceptions.MovieIdNotFoundException;
import com.cg.movies.exceptions.MovieNotFoundException;


public interface MoviesServices {
Movie acceptMoviesDetails(Movie movie);
Movie getMoviesDetails(int movieId)throws MovieNotFoundException;
boolean removeMovie(int movieId)throws MovieIdNotFoundException;
Movie addSongToMovie(int movieId,Song song);
}
