package com.cg.movies.exceptions;

public class MovieIdNotFoundException extends RuntimeException{

	public MovieIdNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MovieIdNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MovieIdNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MovieIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MovieIdNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
