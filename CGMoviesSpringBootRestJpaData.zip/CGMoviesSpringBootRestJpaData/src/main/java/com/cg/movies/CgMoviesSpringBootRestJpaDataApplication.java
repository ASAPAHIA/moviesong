package com.cg.movies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgMoviesSpringBootRestJpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgMoviesSpringBootRestJpaDataApplication.class, args);
	}

}
