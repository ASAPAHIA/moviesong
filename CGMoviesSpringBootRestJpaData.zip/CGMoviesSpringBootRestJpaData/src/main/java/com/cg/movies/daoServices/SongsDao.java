package com.cg.movies.daoServices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.movies.beans.Song;

public interface SongsDao extends JpaRepository<Song, Integer>{

}
