package com.cg.movies.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.movies.beans.Movie;
import com.cg.movies.exceptions.MovieNotFoundException;
import com.cg.movies.services.MoviesServices;
@Controller
public class MoviesServicesController {
	  @Autowired
	    MoviesServices moviesServices;
	    @RequestMapping(value= {"/sayHello"},method=RequestMethod.GET)
	    public ResponseEntity<String> sayHello()
	    {
	        return new ResponseEntity<String>("Hello To All World  From aliens",HttpStatus.OK);
	    }
	    
	    @RequestMapping(value= {"/getMoviesDetails"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	    public ResponseEntity<Movie> getMoviesDetailsRequestParam(@RequestParam int movieId) throws MovieNotFoundException{
	    	Movie movie=moviesServices.getMoviesDetails(movieId);
	        return new ResponseEntity<Movie>(movie,HttpStatus.OK);
	    }
	    @RequestMapping(value="/acceptMoviesDetails",method=RequestMethod.POST,
	            consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	    public ResponseEntity<String>acceptMoviesDetails(@ModelAttribute Movie movie)
	    {
	    	movie=moviesServices.acceptMoviesDetails(movie);
	        return new ResponseEntity<>("Movie details successfully added movieId:-"+movie.getMovieId(),HttpStatus.OK);
	    }
	    @RequestMapping(value="/removeMovie",method=RequestMethod.DELETE,
	            consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	    public ResponseEntity<String>removeMovie(@RequestParam int movieId)throws MovieNotFoundException
	    {
	        moviesServices.removeMovie(movieId);
	        return new ResponseEntity<>("movie details successfully removed",HttpStatus.OK);
	    }      
}
